package ru.anton.dialogpasshider.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.anton.dialogpasshider.config.DialogPassHiderConfig;

import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_11424;
import net.minecraft.class_11444;
import net.minecraft.class_11473;
import net.minecraft.class_11489;
import net.minecraft.class_11521;
import net.minecraft.class_11529;
import net.minecraft.class_11719;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_7919;
import net.minecraft.class_8021;
import net.minecraft.class_8667;

@Mixin(class_11529.class)
public abstract class DialogControlsMixin {

    @Unique
    private static final class_11719 dialogPassHider$eyeIconFont =
        new class_11719.class_11721(class_2960.method_60655("dialog_pass_hider", "eye_icons"));

    @Shadow
    @Final
    private class_11473<?> screen;

    @Shadow
    @Final
    private Map<String, class_11521.class_11522> valueGetters;

    @Unique
    private boolean dialogPassHider$hasPasswordInput;

    @Inject(method = "addInput", at = @At("HEAD"), cancellable = true)
    private void dialogPassHider$maskPasswordInput(
        class_11424 input,
        Consumer<class_8021> widgetConsumer,
        CallbackInfo callbackInfo
    ) {
        if (!(input.comp_4313() instanceof class_11444)
            || !dialogPassHider$shouldMask(input.comp_4312())) {
            return;
        }

        class_11489.method_71903(input.comp_4313(), screen, (widget, valueGetter) -> {
            class_342[] textField = new class_342[1];
            widget.method_48206(child -> {
                if (child instanceof class_342 field) {
                    textField[0] = field;
                }
            });

            class_8021 outputWidget = widget;
            if (textField[0] != null) {
                boolean[] passwordVisible = {false};
                textField[0].method_73210((value, firstCharacterIndex) ->
                    passwordVisible[0]
                        ? null
                        : class_2561.method_43470(DialogPassHiderConfig.getMaskSymbol().repeat(value.length()))
                            .method_30937()
                );

                class_4185 eyeButton = class_4185.method_46430(
                    dialogPassHider$eyeIcon(false),
                    button -> {
                        passwordVisible[0] = !passwordVisible[0];
                        dialogPassHider$updateEyeButton(button, passwordVisible[0]);
                    }
                ).method_46434(0, 0, 24, 20).method_46431();
                dialogPassHider$updateEyeButton(eyeButton, false);

                class_8667 row = class_8667.method_52742().method_52735(4);
                row.method_52736(widget);
                row.method_52738(eyeButton, positioner -> positioner.method_46476());
                row.method_48222();
                outputWidget = row;
            }

            valueGetters.put(input.comp_4312(), valueGetter);
            widgetConsumer.accept(outputWidget);
        });

        callbackInfo.cancel();
    }

    @Unique
    private boolean dialogPassHider$shouldMask(String key) {
        String normalized = key.toLowerCase(Locale.ROOT).replace('-', '_');
        boolean confirmation = normalized.equals("confirm")
            || normalized.equals("confirmation")
            || normalized.contains("confirm_password")
            || normalized.contains("password_confirm");
        boolean password = !confirmation && (
            normalized.equals("pass")
                || normalized.equals("passwd")
                || normalized.contains("password")
        );

        if (password) {
            dialogPassHider$hasPasswordInput = true;
        }

        return password || (confirmation && dialogPassHider$hasPasswordInput);
    }

    @Unique
    private static void dialogPassHider$updateEyeButton(
        class_4185 button,
        boolean passwordVisible
    ) {
        button.method_25355(dialogPassHider$eyeIcon(passwordVisible));
        button.method_47400(class_7919.method_47407(class_2561.method_43471(
            passwordVisible ? "dialog_pass_hider.eye.hide" : "dialog_pass_hider.eye.show"
        )));
    }

    @Unique
    private static class_2561 dialogPassHider$eyeIcon(boolean passwordVisible) {
        return class_2561.method_43470(passwordVisible ? "\ue001" : "\ue000")
            .method_27694(style -> style.method_27704(dialogPassHider$eyeIconFont));
    }
}
