package ru.anton.dialogpasshider.client;

import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7842;
import ru.anton.dialogpasshider.config.DialogPassHiderConfig;

public final class DialogPassHiderConfigScreen extends class_437 {

    private static final int CONTENT_WIDTH = 200;

    private final class_437 parent;
    private class_342 symbolField;
    private class_7842 preview;

    public DialogPassHiderConfigScreen(class_437 parent) {
        super(class_2561.method_43471("dialog_pass_hider.config.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int left = (field_22789 - CONTENT_WIDTH) / 2;
        int top = field_22790 / 2 - 70;

        method_37063(new class_7842(
            left,
            top,
            CONTENT_WIDTH,
            20,
            field_22785,
            field_22793
        ));

        method_37063(new class_7842(
            left,
            top + 28,
            CONTENT_WIDTH,
            12,
            class_2561.method_43471("dialog_pass_hider.config.mask_symbol"),
            field_22793
        ));

        symbolField = method_37063(new class_342(
            field_22793,
            left,
            top + 44,
            CONTENT_WIDTH,
            20,
            class_2561.method_43471("dialog_pass_hider.config.mask_symbol")
        ));
        symbolField.method_1880(2);
        symbolField.method_1852(DialogPassHiderConfig.getMaskSymbol());

        preview = method_37063(new class_7842(
            left,
            top + 70,
            CONTENT_WIDTH,
            12,
            previewText(symbolField.method_1882()),
            field_22793
        ));
        symbolField.method_1863(value -> preview.method_25355(previewText(value)));

        method_37063(class_4185.method_46430(
            class_2561.method_43471("dialog_pass_hider.config.reset"),
            button -> symbolField.method_1852(DialogPassHiderConfig.DEFAULT_MASK_SYMBOL)
        ).method_46434(left, top + 96, 98, 20).method_46431());

        method_37063(class_4185.method_46430(
            class_2561.method_43471("gui.done"),
            button -> saveAndClose()
        ).method_46434(left + 102, top + 96, 98, 20).method_46431());
    }

    private class_2561 previewText(String value) {
        String symbol = DialogPassHiderConfig.normalizeMaskSymbol(value);
        return class_2561.method_43469("dialog_pass_hider.config.preview", symbol.repeat(8));
    }

    private void saveAndClose() {
        DialogPassHiderConfig.setMaskSymbol(symbolField.method_1882());
        method_25419();
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
