package ru.anton.authmepasswordmask.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_11424;
import net.minecraft.class_11444;
import net.minecraft.class_11473;
import net.minecraft.class_11489;
import net.minecraft.class_11521;
import net.minecraft.class_11529;
import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_8021;

/**
 * Adds a visual formatter to dialog text inputs whose key is {@code password}.
 *
 * <p>The formatter only changes rendered text. The field's stored value and the
 * value submitted to the server remain unchanged.</p>
 */
@Mixin(class_11529.class)
public abstract class DialogControlsMixin {

    private static final String PASSWORD_INPUT_KEY = "password";

    @Shadow
    @Final
    private class_11473<?> screen;

    @Shadow
    @Final
    private Map<String, class_11521.class_11522> valueGetters;

    @Inject(method = "addInput", at = @At("HEAD"), cancellable = true)
    private void authmePasswordMask$maskPasswordInput(
        class_11424 input,
        Consumer<class_8021> widgetConsumer,
        CallbackInfo callbackInfo
    ) {
        if (!PASSWORD_INPUT_KEY.equals(input.comp_4312())
            || !(input.comp_4313() instanceof class_11444)) {
            return;
        }

        class_11489.method_71903(input.comp_4313(), screen, (widget, valueGetter) -> {
            widget.method_48206(child -> {
                if (child instanceof class_342 textField) {
                    textField.method_73210((value, firstCharacterIndex) ->
                        class_2561.method_43470("*".repeat(value.length())).method_30937());
                }
            });

            valueGetters.put(input.comp_4312(), valueGetter);
            widgetConsumer.accept(widget);
        });

        callbackInfo.cancel();
    }
}
